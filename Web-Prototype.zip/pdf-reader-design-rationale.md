# Northstar PDF: Design Rationale and Exploration Notes

**Artifact:** `pdf-reader-exploration.html`  
**Pass:** Intelligent analysis reveal, component refinement, and motion polish  
**Date:** 2026-08-24  
**Status:** Concrete exploration pass, not a production capability claim

## 1. Executive view

The follow-up goal was to make the product feel intelligent at first open without making an unsupported promise that an automated system understands every PDF perfectly.

The chosen direction is a **calm evidence workspace**:

1. The document remains the visual center of gravity.
2. Local analysis is visible as a short, purposeful state transition.
3. Findings are mapped onto the document and repeated in the inspector.
4. Native PDF fields and product-inferred regions remain different states.
5. Export is still a new-copy operation with validation and recovery language.

This gives the product a memorable first moment while preserving the current local-first and evidence-gated product boundary.

## 2. What “good-looking” means for this product

For a PDF reader/editor, good-looking does not mean expressive decoration. It means the interface makes a dense, consequential document easier to understand and safer to change.

The quality bar for this pass is:

- **Immediate orientation:** the user knows which document is open, which mode they are in, which page they are viewing, and what the product found.
- **Trustworthy intelligence:** the product explains analysis as evidence discovery, not magical correctness.
- **Low visual fatigue:** the document surface is quiet and warm; tools live in a restrained shell around it.
- **Progressive disclosure:** reading, completion, organization, and review are distinct modes rather than one overloaded toolbar.
- **Recovery visibility:** source preservation, reversible edits, and export validation are visible at the point of action.
- **Accessible density:** controls remain keyboard reachable, labels are explicit, contrast is deliberate, and reduced motion removes transform-heavy feedback.

The audience is a document-intensive professional who completes forms and structured paperwork repeatedly. The business goal is not to out-feature Acrobat. It is to make bounded completion faster, safer, and easier to trust for people who cannot afford a broken layout or an unexplained change.

## 3. Product evidence used

The existing `pdf_editor` reference project establishes the following observed product direction:

- Native macOS is the primary lane, with a browser/local companion.
- The current web lane already exposes PDF import, page modes, fit modes, zoom, rotate, page jump, thumbnails, search, text selection, links, outlines, metadata, permissions, attachments, and encrypted-document retry.
- The core product boundary is bounded completion, not arbitrary existing-text reflow.
- Existing native widgets and inferred static regions must remain separate concepts.
- The static detector is conservative and text-oriented; candidates are not automatically applied.
- Export is intended to create a new copy, reopen it, validate structure, and preserve an operation history.
- Digital-signature validity, permanent redaction, PDF/UA conformance, and broad provider parity remain gated claims.

The current exploration therefore uses a Form 6 sample document as a product-language anchor, not as evidence that the browser prototype is already connected to a live PDF engine.

## 4. Direction selection

### Chosen: Calm evidence workspace

This is a hybrid of modern utility and quiet editorial document handling.

- **Shell:** deep blue-black command frame for chrome and persistent navigation.
- **Canvas:** cool slate workspace that separates the product UI from the document.
- **Document:** warm paper surface with restrained type hierarchy to resemble a real form without recreating a branded product.
- **Accent:** one cobalt interaction color for active selection, controls, and the scan signal.
- **Semantic states:** amber for reviewed inference, green for native or validated state, and red reserved for future failure states.
- **Type:** serif display for document and mode titles, sans for controls and body copy, mono for status, coordinates, counts, and evidence labels.
- **Shape:** small radii and hairlines. Cards are containers for evidence, not the primary visual language.

### Why this direction fits

A pure technical dark theme would make the document feel like a terminal output. A light SaaS dashboard would flatten the distinction between source material and application chrome. The dark shell plus warm paper creates a clear document boundary while preserving operational density.

### Directions considered and not selected

| Direction | Benefit | Decision |
| --- | --- | --- |
| Generic “AI assistant” surface | Immediately signals intelligence | Rejected because chat and glowing suggestion treatments would imply authority before evidence is shown. |
| Full dark reader | Strong cinematic focus | Rejected because long-form document reading and form completion need a quieter paper contrast. |
| Consumer-friendly colored workspace | Approachable for occasional users | Deferred because the current wedge is professional, sensitive paperwork and repeated completion. |
| Spreadsheet-like operations console | Excellent density and auditability | Kept as a future review mode, not used as the whole product because it would subordinate the document. |

## 5. The intelligence reveal

### User experience

On first open, the workspace shows the document underneath a restrained analysis console. The console says:

> Looking for fillable regions

It names the inspected signals: text layer, native widgets, and geometry cues. A short progress bar and scan line provide spatial feedback. The document is not hidden by a full-screen animation and no background loop continues after completion.

When analysis completes:

- The status changes to **5 editable signals found**.
- Native and suggested fields receive a subtle field-level highlight.
- The right inspector already contains the evidence queue.
- The result summary states that the source is unchanged.
- The analysis overlay fades away, leaving the document as the primary surface.

### State model

| State | User-facing meaning | Required behavior |
| --- | --- | --- |
| `idle` | No document is open | Show import/open affordance and privacy boundary. |
| `analyzing` | The local document is being inspected | Show progress, inspected signal categories, and no destructive action. |
| `complete` | Findings are available | Map findings to fields and populate the review queue. |
| `partial` | Some pages or signals could not be analyzed | Identify the unprocessed scope and preserve manual review. |
| `blocked` | Password, size, or provider limitation prevents analysis | Explain the blocker and offer a safe next step. |
| `failed` | Analysis failed | Keep the source open if safe, preserve an error record, and allow retry or reader-only mode. |

The current HTML implements the `analyzing` to `complete` prototype path. The other states are documented as product requirements and should be wired to the actual provider contract before being represented as production claims.

### Why not a permanent AI layer

A persistent assistant, auto-filled fields, or chat panel would create three risks:

1. It would compete with the document for attention.
2. It would make inferred content look equivalent to native PDF semantics.
3. It would make users search for an answer instead of reviewing the evidence attached to a bounded edit.

The selected pattern is closer to a local inspection pass than a conversational copilot. It is more honest and better aligned with the current architecture.

## 6. Component system

### 6.1 Analysis console

**Purpose:** Explain what is happening during first open.  
**Anatomy:** local-analysis kicker, serif state title, short copy, progress track, three inspected-signal chips.  
**Rules:** one time per open or explicit re-analyze action; no looping decoration; never claims semantic certainty.

### 6.2 Analysis status pill

**Purpose:** Keep the completed analysis state visible after the overlay exits.  
**States:** Analysing locally, 5 editable signals found, Analysis unavailable, Reader-only.  
**Rules:** pair status color with text; do not use the dot as the only signal.

### 6.3 Analysis summary

**Purpose:** Give the inspector a compact result summary before the detailed queue.  
**Content:** native field count, review suggestion count, and source-preservation statement.  
**Rules:** show counts only when they come from the provider or clearly labelled sample data; never show confidence as a single overall “AI score.”

### 6.4 Field-found highlight

**Purpose:** Connect the inspector’s evidence to the exact region on the page.  
**States:** found, selected, confirmed, rejected, and unavailable.  
**Rules:** use a short ring animation on discovery, then a quiet outline; never blanket-highlight every text line.

### 6.5 Evidence card

**Purpose:** Present one candidate as a reviewable unit.  
**Anatomy:** field label, evidence type chip, explanation, confidence signal, confirm/reject actions.  
**Rules:** “Needs review” is a product state, not an error; “Native field” is a contract-backed state, not an inferred guess.

### 6.6 Export guardrail

**Purpose:** Connect the product promise to the final action.  
**Content:** new-copy export, reopen validation, page geometry, applied operations, and text outside edited regions.  
**Rules:** remain visible near export and in Review mode; do not place it only in a settings page.

## 7. Motion direction

The motion language is one restrained curve vocabulary: front-loaded cubic-bezier transitions for opacity, color, and state confirmation.

### Implemented motion

- Analysis progress: approximately 1.65 seconds.
- Scan sweep: one functional pass while analysis is active.
- Field discovery: 85ms stagger between mapped fields after analysis completes.
- Overlay exit: delayed fade after the result is written into the persistent status pill.
- Hover and selection: short color and outline transitions already present in the artifact.

### Reduced motion

`prefers-reduced-motion: reduce` collapses animation duration, removes repeated motion, and removes the delayed overlay exit. The static states remain understandable because status labels, chips, field outlines, and text content do not depend on motion.

### Motion that should not be added later

- No ambient shimmer after analysis completes.
- No floating particles, scanning grid, glow aura, or pulsing document border.
- No long stagger over every page thumbnail.
- No transform animation that moves or scales the paper itself during reading.

The product is a productivity tool. Motion should clarify state and location, not perform personality.

## 8. Persona lenses used

The attached persona archive was inspected for the following roles:

### PER-0543: Product Feature Designer

Influence: define the analysis reveal as a bounded capability with states, dependencies, failure behavior, and acceptance criteria rather than jumping directly to a visual effect.

### PER-0795: Form Experience Designer

Influence: keep field semantics and completion order visible; distinguish native widgets from inferred blank regions; make review a deliberate step before export.

### PER-0326: Product UX Designer

Influence: keep the document as the primary surface and use progressive disclosure across Reader, Understand, Complete, Organize, and Review modes.

### PER-0550 and PER-0328: Accessibility roles

Influence: status text accompanies color, focus-visible styles remain present, analysis is announced through a live region, and reduced-motion behavior is explicit.

### PER-0090: Control Surface Architect

Influence: group commands by document workflow and prevent the toolbar from becoming the only place where capability exists.

### PER-0922 and PER-0923: Epistemic Integrity and Evidence roles

Influence: use language such as “signal,” “suggestion,” and “review” instead of claiming that analysis has understood the document. Keep source preservation and validation visible.

The personas are lenses, not separate product modes. The product should not expose a persona picker to end users for this workflow.

## 9. Interaction options and decisions

### Option A: One-time automatic analysis on open — selected

Best fit for the requested first impression. It creates immediate value and lets the user begin from a mapped document. It requires reliable cancellation, provider-backed progress, and explicit fallback states in production.

### Option B: User-triggered “Analyze document” action

Safer for privacy and compute predictability, but it makes the first open feel inert and hides the product’s main differentiator. Keep this as a secondary re-analyze action.

### Option C: Always-on analysis while editing

Could catch newly revealed regions, but risks performance, surprising mutations, and excessive attention cost. Defer until there is a measured need and a clear incremental-analysis contract.

### Option D: Conversational “Ask the PDF” assistant

Potentially valuable for extraction and navigation, but not the right first intelligence surface. It changes the authority model and demands answer provenance, prompt-injection handling, and stronger privacy controls.

## 10. Acceptance criteria for the next real implementation

The prototype pass should become a product feature only when the implementation can prove:

- Analysis begins after a verified document load, not before bytes are available.
- The user can cancel or switch to reader-only mode.
- Each finding carries page index, page-space bounds, evidence origin, and confidence or abstention state.
- Native fields and static suggestions are rendered with separate semantics and separate mutation paths.
- No candidate is applied automatically.
- Partial and blocked analysis states name the affected pages and the available fallback.
- A confirmed edit is appended to the operation log and can be undone by rebuilding from immutable source bytes.
- Export writes a new copy, reopens it, and produces a validation report.
- Search, keyboard navigation, screen-reader status, and reduced motion work while analysis is active and after it completes.
- The product does not claim digital-signature validity, permanent redaction, PDF/UA conformance, or arbitrary text reflow without separate evidence.

## 11. Verification record for this pass

Verified statically in `pdf-reader-exploration.html`:

- Analysis overlay, status pill, result summary, and field-level highlight hooks are present.
- The motion layer uses transform/opacity-oriented feedback and a reduced-motion media query.
- No `scrollIntoView()` call was added.
- The existing file remains self-contained and keeps its semantic `data-od-id` targets.
- No external media or API dependency was introduced.

Not verified in this pass:

- Actual PDF.js provider timing and progress events.
- Browser or assistive-technology observation.
- Rendered screenshot inspection, because the Open Design export runtime was unavailable in the previous session.
- Accuracy of field detection on real documents. The current visual result is an interaction exploration, not detection evidence.

## 12. Recommended next step

Connect the analysis state model to the provider-neutral contract already described in the reference project. The browser lane should emit a manifest of pages, native fields, and conservative candidates first. The UI can then replace the sample 1.65-second timer with real progress, partial completion, cancellation, and evidence-backed counts without changing the visual system.

## 13. Ship-polish pass

The follow-up polish pass focused on the highest-impact usability and accessibility risks rather than changing the visual direction.

### Fixes applied

- Increased primary toolbar and navigation targets to a denser desktop baseline with 44px targets on coarse pointers.
- Added a visible `Open reader now` escape hatch during local analysis.
- Made the analysis status pill retryable after completion or skip.
- Added explicit `Analysis in progress`, `Analysis complete`, and `Analysis skipped` summary states.
- Added `aria-controls` to mode tabs and real `tabpanel` targets for Reader, Understand, Complete, Organize, and Review.
- Added Arrow Left, Arrow Right, Home, and End keyboard movement across workspace tabs.
- Added keyboard activation for field regions through Enter and Space.
- Added focus-visible treatment to detected field regions.
- Changed search feedback from every-keystroke to deliberate Enter-to-search feedback, removing notification noise.
- Kept reduced-motion behavior intact for the analysis reveal and field-found highlights.

### Why these fixes matter

The analysis reveal is now a product state with recovery, not a mandatory animation. A user on a slow device, a keyboard, or a reduced-motion setting can continue reading without being trapped in the presentation layer.

The workspace modes now have a reliable accessibility relationship between tab controls and the active panel. This is especially important because the five modes are a product information architecture decision, not merely a visual nav treatment.

The field regions now behave as keyboard-reachable inspection targets. They remain read-only visual surfaces in this exploration, but the interaction contract is ready for a later field editor or candidate review dialog.

### Remaining open verification

- Run a browser interaction pass at 360, 390, 430, 600, 768, 820, 1024, 1366, and 1440px.
- Observe the analysis announcement and tab sequence with VoiceOver or another assistive technology.
- Replace timer-driven prototype analysis with provider-backed progress, cancellation, partial success, and error recovery.
- Verify color contrast in the rendered artifact, especially semantic amber states on the warm paper and the dark shell’s muted navigation labels.
- Run the supplied web-reader contract check separately against the linked reference app at `/Users/pranay/Projects/pdf_editor/web/index.html`; this exploration is intentionally a distinct Design Files artifact.

## 14. First-principles product pass

The linked `pdf_editor` repository was rechecked before this update. Its most durable product decision is not a visual feature. It is the controlled document mutation pipeline:

1. Open immutable source bytes.
2. Inspect fields, text, geometry, page structure, and provider facts.
3. Present uncertain regions as evidence-backed suggestions.
4. Require review before applying inferred changes.
5. Record accepted changes as reversible operations.
6. Export a new copy and validate it by reopening and checking structure, geometry, and edited-region preservation.

The repository’s feature inventory also makes an important distinction between native widgets, static blank-region suggestions, OCR evidence, overlays, annotations, page operations, and high-risk lanes such as permanent redaction, cryptographic signatures, XFA, and PDF/UA. The visual system now makes that same distinction legible to the user.

### 14.1 IA decision: source, model, mutation, proof

The workspace modes now follow a five-part product model:

| Mode | User question | Product responsibility |
|---|---|---|
| Reader | What is in the source? | Render, search, inspect, and preserve the reading context. |
| Understand | What does the system know or infer? | Show document structure, evidence, uncertainty, and the next useful action. |
| Complete | What am I willing to change? | Separate native field edits from reviewed suggestions and keep acceptance explicit. |
| Organize | How should the pages be structured? | Keep page-level operations separate from content mutation. |
| Review | What will leave the session? | Show operation history, validation intent, and product boundaries before export. |

This is deliberately broader than a reader plus an assistant, but narrower than a claim to edit every PDF object. It gives future capabilities a stable home without making every feature compete for a toolbar slot.

### 14.2 AI-native behavior without an assistant-shaped UI

The new Understand mode is the first AI-native surface in the exploration. It uses three patterns:

- **Document map:** group findings by meaningful document section instead of presenting a flat list of model outputs.
- **Next best action:** surface the most useful review step with a reason, evidence origin, page, and confidence signal.
- **Structured questions:** let users ask bounded intents such as finding dates or showing uncertain regions. The result changes the inspected state or queue; it does not produce an ungrounded prose answer.

The language intentionally remains “signal,” “suggestion,” “review,” and “evidence.” A future model can add OCR, layout extraction, classification, or retrieval behind these contracts, but it should not change the user’s authority model.

### 14.3 Long-term component direction

The next component family should be built around inspectable states rather than generic cards:

- `DocumentMap`: source sections, page ranges, and evidence count.
- `EvidenceRow`: label, evidence origin, page/geometry context, and review state.
- `NextAction`: a single recommended action with reason and safe fallback.
- `IntentChip`: a bounded document query that resolves to a visible state change.
- `OperationLedger`: accepted operations, previous values, undo/rebuild state, and export readiness.
- `CapabilityBoundary`: an explicit explanation of what is not claimed yet.
- `ValidationReport`: new-copy checks, warnings, failures, and next-check actions.

These components can be implemented in the native macOS shell and the browser companion through the existing provider-neutral contracts. They should remain useful when analysis is partial, unavailable, or intentionally skipped.

### 14.4 Options considered

**Keep four modes and add intelligence to the inspector.** This would be cheaper, but it would make AI a side effect of the completion queue and give document understanding no durable information architecture.

**Add an “Ask PDF” chat panel.** This is attractive for demos, but it introduces answer provenance, prompt-injection handling, privacy controls, and a new expectation that every question should be answered conversationally. It is better as a later bounded retrieval surface, not the foundation.

**Use an always-on ambient copilot.** This would compete with reading and editing attention, create unclear compute behavior, and make it difficult to distinguish analysis from mutation. The product should prefer explicit state transitions and one-shot evidence reveals.

**Selected direction: a visible document model.** It makes intelligence feel present while keeping the source, inference, approval, operation, and validation layers distinct.

### 14.5 Acceptance criteria for the next build slice

- Understand mode is driven by the provider-neutral document manifest, not hard-coded counts.
- Every evidence row exposes page index, page-space bounds, evidence origin, and abstention or confidence state.
- Structured questions resolve to inspectable result states and can be cancelled or cleared.
- Partial analysis names what is available and what is pending; it never blocks Reader mode.
- Approved suggestions append to the operation log and remain reversible.
- Review mode can expand into a validation report that distinguishes success, warning, unknown, and failure.
- Native and web lanes share terminology and state semantics even when provider capability differs.
- No surface implies digital-signature validity, permanent redaction, PDF/UA conformance, or arbitrary text reflow without the separate evidence lanes already documented in the repository.

## 15. Manifest implementation slice

The exploration now includes a local adapter-shaped `pdf-editor.document` manifest that follows the linked repository’s `PDFContractEnvelope<DocumentInspection>` vocabulary.

### Manifest fields represented in the prototype

- `header.contractName`, version, source digest, generated timestamp, and provider descriptor.
- `payload.source` with file name, byte count, and SHA-256 identity.
- `payload.pages` with zero-based page indexes, labels, crop-box bounds, rotation, character counts, annotation counts, and selectable-text state.
- `payload.fields` with native field IDs, names, kinds, page indexes, bounds, values, and choices.
- `payload.candidates` with candidate kind, review status, score, suggested field type, entry mode, page-space coordinate, source digest, and typed `evidenceItems`.
- Evidence items with the repository’s origins such as `textExtraction` and `geometryExtraction`, plus typed kinds, summaries, text, score, provider, and page-space regions.

The source manifest is treated as immutable. The prototype keeps accepted suggestions in a separate operation log with an operation ID, candidate ID, page index, coordinate, source digest, and reversible state. That is the same conceptual boundary as `RegionCandidate` versus `EditOperation` in the native/web contract.

### Analysis state

The opening reveal is now a four-stage adapter state machine:

```text
idle
  -> source digest
  -> page structure
  -> native fields
  -> review signals
  -> complete
```

The user can cancel at any point. The UI reports completed passes, keeps any already-known counts honest, leaves the source available in Reader mode, and offers a retry path. The stages are intentionally local and provider-labelled in the prototype so the future browser adapter can replace the timers with actual worker or companion progress events.

### Validation state

Review mode now exposes a contract preflight rather than claiming that validation already passed. The preview includes the repository’s check kinds:

- `sourceDigest`: passed when the session is still bound to the manifest source.
- `appliedOperations`: passed or warning depending on whether accepted operations are source-bound.
- `outputReopen`: unknown until a new output exists.
- `pageGeometry`: unknown until page bounds and rotation are compared after reopen.
- `outsideRegionText`: unknown until unrelated content is compared after export.
- `providerCapability`: warning until the provider’s independent preservation evidence is available.

This is intentionally a preflight result. It is not a `validated`, `validatedWithWarnings`, or `failed` export report because the exploration has not produced a new PDF output. The distinction prevents a visually convincing prototype from teaching the wrong product behavior.

### What the next production adapter must replace

- Replace the in-file manifest with the browser or native provider’s serialized `pdf-editor.document` envelope.
- Replace timer progression with cancellable provider events and a typed partial-result stream.
- Preserve page-space coordinates at the adapter boundary instead of deriving persisted geometry from the rendered canvas.
- Replace the preflight preview with the actual `pdf-editor.validation` envelope after export and reopen.
- Keep unknown and abstained states visible instead of collapsing them into a low confidence number or a generic failure message.

## 16. Motion pass

The motion pass adds only transitions that explain a real state change:

- Mode surfaces enter with a 240ms opacity and 6px translate transition when the user moves between Reader, Understand, Complete, Organize, and Review.
- Manifest evidence rows enter after the provider-shaped manifest is rendered, using a 280ms opacity and 5px translate reveal with a 45ms row stagger. The order is supplied by the rendered page list, not a separate hard-coded animation sequence.
- The analysis mark shimmer and document scan sweep run only while the analysis overlay is active. Both stop when analysis completes or is cancelled, avoiding ambient motion after the state has settled.
- Button and chip press feedback uses a 100ms, 1px translate response. Stage chips use 150ms color, border, and focus-ring transitions so the active analysis stage is legible without competing with the document.

All transform-based motion has a `prefers-reduced-motion` fallback. Reduced-motion users receive the final visible mode and evidence rows immediately, while semantic progress, cancellation, confidence, and validation states remain unchanged.
